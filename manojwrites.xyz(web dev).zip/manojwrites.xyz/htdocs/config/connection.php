<?php
// --- ADD THIS PART AT THE VERY TOP ---
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Ensure anonymous secure device/session token
if (!isset($_SESSION['anon_id'])) {
    try {
        $_SESSION['anon_id'] = bin2hex(random_bytes(32)); // 64-char secure token
    } catch (Exception $e) {
        $_SESSION['anon_id'] = bin2hex(openssl_random_pseudo_bytes(32)); 
    }
}

    $con=mysqli_connect("sql110.infinityfree.com","if0_39164740","Manoj2409","if0_39164740_manojwrites_db");

    if(mysqli_connect_error()){
        echo "not connected";
    }
    
    
   define("UPLOAD_SRC",$_SERVER['DOCUMENT_ROOT']."/login/uploads/");


    define("FETCH_SRC","https://manojwrites.xyz/login/uploads/");


// ================================
// PRIVATE SYNC SECRET
// ================================
define('SYNC_SECRET', '7e3c9aF1D8QkZ2mT6J0xV5LrU8pH9Ayb');

?>
















