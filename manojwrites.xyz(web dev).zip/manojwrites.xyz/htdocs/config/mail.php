<?php
// config/mail.php

// Gmail SMTP credentials (App Password, NOT Gmail password)
define('MAIL_USER', 'cloudmovies0001@gmail.com');
define('MAIL_PASS', 'fjvq iyoh rsih liqa');

// Optional: sender name
define('MAIL_FROM_NAME', 'Admin Panel');