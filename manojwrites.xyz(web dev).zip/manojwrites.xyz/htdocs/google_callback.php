<?php
session_start();
require_once("./config/connection.php");

$client_id = "261269655638-igmlciarsuotqn3bls96031nu2faa6eo.apps.googleusercontent.com";
$client_secret = "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";
$redirect_uri = "https://manojwrites.xyz/google_callback.php";

if (!isset($_GET['code'])) {
    die("Login failed: No OAuth code received");
}

$code = $_GET['code'];

// 1️⃣ Exchange code for access token
$token_url = "https://oauth2.googleapis.com/token";

$data = [
    "code" => $code,
    "client_id" => $client_id,
    "client_secret" => $client_secret,
    "redirect_uri" => $redirect_uri,
    "grant_type" => "authorization_code"
];

$options = [
    "http" => [
        "header" => "Content-Type: application/x-www-form-urlencoded\r\n",
        "method" => "POST",
        "content" => http_build_query($data)
    ]
];

$response = file_get_contents($token_url, false, stream_context_create($options));
$token_info = json_decode($response, true);

$access_token = $token_info["access_token"];

// 2️⃣ Fetch user profile
$profile = file_get_contents("https://www.googleapis.com/oauth2/v2/userinfo?access_token=" . $access_token);
$user = json_decode($profile, true);

$google_id = $user["id"];
$name = $user["name"];
$email = $user["email"];
$picture = $user["picture"];

// 3️⃣ Save or update user in DB
$stmt = $con->prepare("
    INSERT INTO users (google_id, name, email, picture)
    VALUES (?, ?, ?, ?)
    ON DUPLICATE KEY UPDATE 
        name=VALUES(name),
        picture=VALUES(picture)
");
$stmt->bind_param("ssss", $google_id, $name, $email, $picture);
$stmt->execute();
$stmt->close();

// 4️⃣ Save user session
$_SESSION["user_id"] = $google_id;
$_SESSION["user_name"] = $name;
$_SESSION["user_email"] = $email;
$_SESSION["user_pic"] = $picture;

// 5) Redirect user back to the page they came from
if (isset($_SESSION['redirect_after_login'])) {
    $url = $_SESSION['redirect_after_login'];
    unset($_SESSION['redirect_after_login']);
    header("Location: $url");
    exit();
}

// fallback
header("Location: /index.php");
exit();