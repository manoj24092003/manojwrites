<?php
session_start();

$client_id = "261269655638-igmlciarsuotqn3bls96031nu2faa6eo.apps.googleusercontent.com";
$redirect_uri = "https://manojwrites.xyz/google_callback.php";

$scope = urlencode("email profile");

$url =
"https://accounts.google.com/o/oauth2/v2/auth?" .
"client_id={$client_id}" .
"&redirect_uri={$redirect_uri}" .
"&response_type=code" .
"&scope={$scope}" .
"&access_type=online" .
"&prompt=select_account";

header("Location: $url");
exit;