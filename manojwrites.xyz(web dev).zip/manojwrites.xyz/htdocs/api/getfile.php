<?php
header("Content-Type: application/json");

$slug    = $_GET['slug'] ?? '';
$season  = $_GET['season'] ?? null;
$episode = $_GET['episode'] ?? null;

if (!$slug) {
    echo json_encode(["error" => "slug missing"]);
    exit;
}

// SERIES
if ($season && $episode) {
    echo json_encode([
        "filename" => "https://video.manojwrites.xyz/watch/$slug/season-$season/episode-$episode/index.m3u8"
        
    ]);
    exit;
}

// MOVIE
echo json_encode([
    "filename" => "https://video.manojwrites.xyz/watch/$slug/index.m3u8"
    
]);


