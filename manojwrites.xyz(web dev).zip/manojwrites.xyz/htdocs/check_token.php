<?php
header("Content-Type: application/json");
require_once "./config/connection.php";

$token = $_POST['token'] ?? '';

if (!$token) {
    echo json_encode(["valid" => false]);
    exit;
}

$stmt = $con->prepare("SELECT id FROM fcm_tokens WHERE token = ? LIMIT 1");
$stmt->bind_param("s", $token);
$stmt->execute();
$stmt->store_result();

echo json_encode([
    "valid" => $stmt->num_rows > 0
]);

$stmt->close();
?>